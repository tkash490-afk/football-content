# Security Specification: Football SaaS Web App

## 1. Data Invariants
1. A subscription record cannot be modified by any non-admin user.
2. A plan cannot be created or modified by any non-admin user.
3. User details or premium subscriptions cannot be modified under a role spoof.
4. Notifications are system-generated and can only be created by admins.
5. Users can only read their own profile, subscription logs, saved posts, and content generation history.
6. System-wide broadcast notifications are readable by all authenticated users, but writable only by admins.
7. Creation of user profiles must enforce valid schemas (matching string formats, sizes, and timestamps).

## 2. The "Dirty Dozen" Payloads
These payloads attempt to bypass identity, integrity, or write rules:

1. **Self-Upgrade Injection**: Non-premium user attempts to write `"subscriptionStatus": "active"` directly to their user profile.
2. **PII Data Extraction**: Guest user attempts to read other users' documents in `/users/` collection.
3. **Admin Privilege Escalation**: User attempts to create an admin entry `/admins/{auth.uid}` to gain admin access.
4. **Plan Price Spoof**: Guest attempt to set a plan's price to `0` or negative numbers.
5. **System Notification Hijack**: Regular user attempts to post a system broadcast notification.
6. **AI History Modification**: User attempts to modify or update an existing AI history record (`/generatedContents/{id}`) to inject false prompt records.
7. **Orphaned Subscription Creation**: User attempts to create a subscription log referencing a non-existent plan ID.
8. **Malicious ID Poisoning**: Attacker attempts to create a plan with an ID containing `../../../admin/poison` or huge junk data size.
9. **Timestamp Manipulation**: Client sends a future `createdAt` timestamp to skip daily limits or billing period start.
10. **System Status Overwrite**: User attempts to modify terminal-locked subscription entries from "success" to other values.
11. **Shadow Field Inundation**: User attempts to create profile with additional unauthorized secret fields like `"isAdmin": true`.
12. **Foreign List Pollution**: User attempts to insert arbitrary items to search queries and favorites list that exceed size quotas.

## 3. Security Rules Summary
The Firestore Rules enforce strict check gates:
- Master Gate relation constraints.
- Admin authentication by email verification checking the bootstrapped administrator email (`stevenjames2852@gmail.com`).
- Split-action updates for `/users/{userId}` distinguishing preference modification and billing-triggered subscription updates.
