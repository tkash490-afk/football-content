export interface UserProfile {
  uid: string;
  email: string;
  name: string;
  favoriteClubs: string[];
  subscriptionId: string; // 'free', or planId
  subscriptionStatus: 'active' | 'inactive' | 'expired';
  subscriptionExpiry: string; // ISO string
  savedPosts: string[]; // Holds saved article IDs or titles
  dailyGenerationCount: number;
  lastGenerationDate: string; // YYYY-MM-DD
  createdAt: string;
  isAdmin?: boolean;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number; // in NGN
  durationDays: number;
  features: string[];
  status: 'active' | 'inactive';
  createdAt: string;
}

export interface SubscriptionPayment {
  id: string;
  userId: string;
  planId: string;
  amount: number;
  status: 'success' | 'failed' | 'pending';
  reference: string;
  startDate: string;
  expiryDate: string;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  userId: string; // 'all' or specific uid
  title: string;
  message: string;
  type: 'breaking' | 'transfer' | 'billing' | 'saved_reminder' | 'system';
  isRead: boolean;
  createdAt: string;
}

export interface GeneratedContent {
  id: string;
  userId: string;
  prompt: string;
  result: string;
  type: 'tweet' | 'thread' | 'analysis';
  createdAt: string;
}

export interface FootballNews {
  id: string;
  title: string;
  summary: string;
  content?: string;
  source: string;
  url?: string;
  category: 'transfer' | 'breaking' | 'confirmed_transfer' | 'match_result' | 'manager_sacking' | 'injury' | 'controversy' | 'general';
  points: number; // For the Smart Trending System algorithm
  clubs: string[];
  players: string[];
  createdAt: string; // ISO string
  image?: string;
}
