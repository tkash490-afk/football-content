import React, { useState, useEffect } from "react";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { NewsFeed } from "./components/NewsFeed";
import { AIWriter } from "./components/AIWriter";
import { AdminHQ } from "./components/AdminHQ";
import { BellNotificationPanel } from "./components/BellNotificationPanel";
import { AuthModal } from "./components/AuthModal";
import { PaystackModal } from "./components/PaystackModal";
import { db, handleFirestoreError, OperationType } from "./firebase";
import { 
  collection, 
  query, 
  where, 
  orderBy, 
  limit, 
  onSnapshot, 
  setDoc, 
  doc, 
  getDocs 
} from "firebase/firestore";
import { SubscriptionPlan, AppNotification, FootballNews } from "./types";
import { 
  Sparkles, Shield, User, Crown, LogIn, LogOut, Layers, 
  Bookmark, Menu, X, ArrowRight, Check, CheckCircle, 
  Play, Radio, Calendar, Info, Globe, Activity 
} from "lucide-react";

// Initializing static seeder for required default plans
const SEED_PLANS: SubscriptionPlan[] = [
  {
    id: "two_weeks",
    name: "Two Week Plan",
    price: 1000,
    durationDays: 14,
    features: [
      "Unlimited content generation",
      "Unlimited tweet variations",
      "Priority thread generation",
      "Advanced AI temperature tweaks",
      "Complete historical sports records",
      "Early access to new tactical features"
    ],
    status: "active",
    createdAt: new Date().toISOString()
  },
  {
    id: "monthly_vip",
    name: "Monthly VIP Plan",
    price: 2000,
    durationDays: 30,
    features: [
      "Everything in Two Week Plan",
      "Unlimited premium thread exports",
      "Full access to the tactical review publisher",
      "VIP priority prompt generation Speed",
      "No-Code support features"
    ],
    status: "active",
    createdAt: new Date().toISOString()
  }
];

function DashboardContent() {
  const { userProfile, loading, logout, toggleSavePost } = useAuth();
  
  // Tab states: 'feed' | 'writer' | 'pricing' | 'admin' | 'saved'
  const [activeTab, setActiveTab] = useState<"feed" | "writer" | "pricing" | "admin" | "saved">("feed");
  
  // Search state managed globally
  const [searchQuery, setSearchQuery] = useState("");

  // Modals state
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isPaystackOpen, setIsPaystackOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);

  // Dynamic lists from Firestore
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  const [savedArticles, setSavedArticles] = useState<FootballNews[]>([]);

  // Mobile menu parameters
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // 1. Seed & fetch subscription plans, register reactive listeners for notifications
  useEffect(() => {
    // A. Seedplans if table is empty
    const handleSeedAndFetchPlans = async () => {
      try {
        const plansSnap = await getDocs(collection(db, "plans"));
        if (plansSnap.empty) {
          console.log("Seeding default subscription pricing plans...");
          for (const plan of SEED_PLANS) {
            await setDoc(doc(db, "plans", plan.id), plan);
          }
          setPlans(SEED_PLANS);
        } else {
          const loadedPlans: SubscriptionPlan[] = [];
          plansSnap.forEach(snap => {
            loadedPlans.push(snap.data() as SubscriptionPlan);
          });
          setPlans(loadedPlans);
        }
      } catch (err) {
        console.warn("Pricing configurations seeding skipped:", err);
      }
    };
    handleSeedAndFetchPlans();

    // B. If user auth is loaded, attach live listeners for system notifications
    if (userProfile?.uid) {
      const q = query(
        collection(db, "notifications"),
        where("userId", "in", [userProfile.uid, "all"]),
        orderBy("createdAt", "desc"),
        limit(20)
      );

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const items: AppNotification[] = [];
        let unread = 0;
        snapshot.forEach(docSnap => {
          const notif = docSnap.data() as AppNotification;
          items.push(notif);
          if (!notif.isRead) unread++;
        });
        setNotifications(items);
        setUnreadCount(unread);
      }, (err) => {
        handleFirestoreError(err, OperationType.LIST, "notifications");
      });

      return unsubscribe;
    } else {
      setNotifications([]);
      setUnreadCount(0);
    }
  }, [userProfile?.uid]);

  // Sync bookmarked articles
  useEffect(() => {
    const fetchBookmarks = async () => {
      if (!userProfile?.uid || !userProfile.savedPosts || userProfile.savedPosts.length === 0) {
        setSavedArticles([]);
        return;
      }
      try {
        const response = await fetch("/api/news");
        const resData = await response.json();
        if (resData.success && resData.news) {
          const saved = resData.news.filter((n: FootballNews) => userProfile.savedPosts.includes(n.id));
          setSavedArticles(saved);
        }
      } catch (err) {
        console.warn("Bookmarks rendering error:", err);
      }
    };
    fetchBookmarks();
  }, [userProfile?.uid, userProfile?.savedPosts]);

  const isPremium = userProfile?.subscriptionStatus === "active" && 
                    new Date(userProfile?.subscriptionExpiry || "") > new Date();

  return (
    <div className="min-h-screen bg-[#050505] text-[#e5e5e5] flex flex-col font-sans selection:bg-blue-500/30 selection:text-white" id="main-sports-application">
      
      {/* 1. TOP NAVIGATION BAR */}
      <header className="sticky top-0 z-40 bg-[#0a0a0a] border-b border-white/10 backdrop-blur-sm px-4 lg:px-8 py-3.5 flex items-center justify-between shadow-md shrink-0">
        
        {/* Brand Logo and Title */}
        <div className="flex items-center gap-2.5 shrink-0 select-none">
          <div className="p-2 bg-blue-600 rounded-xl shadow-lg shadow-blue-600/20 text-white flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-sm font-black tracking-wider text-white uppercase font-display select-text flex items-center gap-1">
              ApexFootball <span className="bg-blue-500/15 text-blue-400 font-extrabold text-[9px] tracking-wide px-1.5 py-0.5 rounded uppercase">SaaS</span>
            </h1>
            <p className="text-[10px] text-white/50 font-medium font-mono leading-none mt-0.5 select-text">
              GLOBAL AI CONTENT SPORTS ENGINE
            </p>
          </div>
        </div>

        {/* Global Nav Search input - triggers on news filters */}
        <div className="hidden lg:flex items-center gap-2 max-w-xl w-full relative">
          <span className="text-white/40 absolute left-3.5 top-2.5">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </span>
          <input
            type="text"
            placeholder="Search clubs, players, competitions... (e.g., Chelsea)"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setActiveTab("feed");
            }}
            className="w-full bg-[#151515] border border-white/10 rounded-lg pl-10 pr-4 py-2 text-xs focus:outline-none focus:border-blue-500/50 text-[#e5e5e5] placeholder-white/40 transition-all font-sans"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery("")} className="absolute right-3.5 top-2 text-xs text-rose-400 font-bold hover:text-rose-500 cursor-pointer">
              ×
            </button>
          )}
        </div>

        {/* Action Controls block */}
        <div className="flex items-center gap-3">
          
          {/* Bell Notification dropdown component */}
          {userProfile && (
            <BellNotificationPanel 
              notifications={notifications} 
              unreadCount={unreadCount} 
            />
          )}

          {/* Premium tag status badge */}
          {userProfile && (
            <div className={`hidden md:flex items-center gap-2 px-3 py-1 rounded-full border text-xs font-semibold ${
              isPremium 
                ? "bg-blue-500/10 border-blue-500/20 text-blue-400"
                : "bg-white/5 border-white/10 text-white/60"
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${isPremium ? "bg-blue-400 animate-pulse" : "bg-white/30"}`}></span> 
              <span>{isPremium ? "PREMIUM USER" : "FREE CREATOR PLAN"}</span>
            </div>
          )}

          {/* Profiler Menu / Auth Trigger states */}
          {loading ? (
            <div className="w-8 h-8 rounded-full border border-white/10 border-t-transparent animate-spin shrink-0" />
          ) : userProfile ? (
            <div className="flex items-center gap-2">
              <div className="hidden lg:block text-right">
                <p className="text-xs font-bold text-white select-all">{userProfile.name}</p>
                <p className="text-[9px] text-[#e5e5e5]/50 font-semibold font-mono tracking-wide mt-0.5 uppercase">
                  {userProfile.email}
                </p>
              </div>
              <button 
                onClick={logout}
                className="p-1.5 px-2.5 rounded-lg bg-white/5 border border-white/10 text-rose-450 hover:bg-white/10 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                title="Sign out of portal"
              >
                <LogOut className="w-3.5 h-3.5" /> <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          ) : (
            <button
              onClick={() => setIsAuthOpen(true)}
              className="p-2 px-4 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-lg shadow-blue-500/10 font-display"
            >
              <LogIn className="w-4 h-4" /> Sign In / Join
            </button>
          )}

          {/* Mobile menu select */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg bg-[#0a0a0a] border border-white/10 text-white/70 hover:text-white"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* 2. MAIN APPLICATION CONTENT PORTAL */}
      <div className="flex-grow flex flex-col lg:flex-row">
                {/* LEFT COLUMN SIDEBAR NAVIGATION PANEL */}
        <aside className={`${
          isMobileMenuOpen ? "block" : "hidden"
        } lg:block w-full lg:w-64 bg-[#080808] border-r border-white/10 shrink-0 select-none pb-8 lg:sticky lg:top-[74px] lg:h-[calc(100vh-74px)] overflow-y-auto`}>
          
          <div className="p-4 space-y-6">
            
            {/* Search filter for mobile view */}
            <div className="lg:hidden">
              <input
                type="text"
                placeholder="Search clubs, players, competitions..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setActiveTab("feed");
                }}
                className="w-full bg-[#151515] pl-4 pr-4 py-2 rounded-lg border border-white/10 focus:border-blue-500/50 text-[#e5e5e5] placeholder-white/40 focus:outline-none text-xs font-sans"
              />
            </div>

            {/* Navigation items list */}
            <div className="space-y-1">
              <p className="px-3 py-2 text-[10px] uppercase tracking-widest text-white/40 font-bold">Main Menu</p>
              
              {[
                { key: "feed", label: "Smart News Feed", icon: Globe, badge: "Global" },
                { key: "writer", label: "Football AI Writer", icon: Sparkles, badge: "AI Powered" },
                { key: "pricing", label: "Pricing & Plans", icon: Crown, badge: "₦ NGN" },
                { key: "saved", label: "Saved & History", icon: Bookmark }
              ].map(item => {
                const SelectedIcon = item.icon;
                const isCurrent = activeTab === item.key;
                return (
                  <button
                    key={item.key}
                    onClick={() => {
                      setActiveTab(item.key as any);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full px-3 py-2.5 rounded-lg text-xs font-semibold flex items-center justify-between cursor-pointer transition-all ${
                      isCurrent
                        ? "bg-white/5 text-white border border-white/10 border-l-4 border-l-blue-500 shadow-sm"
                        : "text-white/70 hover:bg-white/5 hover:text-white border border-transparent"
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <SelectedIcon className="w-4 h-4 shrink-0" />
                      <span>{item.label}</span>
                    </div>
                    {item.badge && (
                      <span className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded ${
                        isCurrent ? "bg-blue-500/10 text-blue-400" : "bg-white/5 text-white/40 border border-white/10"
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Admin navigation Section */}
            {userProfile?.isAdmin && (
              <div className="space-y-1 pt-4 border-t border-white/10">
                <p className="px-3 py-2 text-[10px] uppercase tracking-widest text-white/40 font-bold flex items-center gap-1.5 text-rose-400">
                  <Shield className="w-3.5 h-3.5" /> Admin HQ
                </p>
                <button
                  onClick={() => {
                    setActiveTab("admin");
                    setIsMobileMenuOpen(false);
                  }}
                  className={`w-full px-3 py-2.5 rounded-lg text-xs font-semibold flex items-center gap-2.5 cursor-pointer transition-all ${
                    activeTab === "admin"
                      ? "bg-white/5 text-rose-400 border border-white/10 border-l-4 border-l-rose-500 font-extrabold shadow-sm"
                      : "text-white/70 hover:bg-white/5 hover:text-rose-400 border border-transparent"
                  }`}
                >
                  <Layers className="w-4 h-4 shrink-0" />
                  <span>Admin settings panel</span>
                </button>
              </div>
            )}

            {/* Quick stats panel / Usage details matching template */}
            {userProfile && (
              <div className="p-4 bg-gradient-to-br from-blue-600/10 to-transparent rounded-2xl border border-white/5 space-y-3">
                <div className="text-xs font-semibold">Creator Usage Details</div>
                
                <div className="space-y-2 text-[11px]">
                  <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 transition-all duration-500" style={{ width: isPremium ? "100%" : `${Math.min(100, ((userProfile.dailyGenerationCount || 0) / 3) * 100)}%` }}></div>
                  </div>
                  <div className="flex justify-between text-white/60 font-mono text-[10px]">
                    <span>GENERATIONS USED:</span>
                    <span className="font-bold text-white">{isPremium ? "UNLIMITED" : `${userProfile.dailyGenerationCount || 0} / 3`}</span>
                  </div>
                </div>

                <div className="pt-1.5 border-t border-white/5 space-y-1.5 text-[10px] text-white/50">
                  <div className="flex justify-between">
                    <span>Bookmarks Total:</span>
                    <span className="font-semibold text-white font-mono">{userProfile.savedPosts?.length || 0} saved</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Monitored Clubs:</span>
                    <span className="font-semibold text-white font-mono">{userProfile.favoriteClubs?.length || 0} clubs</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </aside>

        {/* RIGHT COLUMN MAIN INTERACTION CONTAINER VIEW */}
        <main className="flex-grow p-4 lg:p-8 overflow-y-auto bg-[#050505]">
          
          {/* Main Workspace Router Tab Components */}

          {/* TAB 1: Smart News Feed */}
          {activeTab === "feed" && (
            <div className="space-y-6">
              {/* Shortcut trigger if search match is detected for a club */}
              {searchQuery.trim() && (
                <div className="p-4 bg-blue-500/5 border border-blue-500/20 text-blue-400 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs font-semibold">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    <span>Want to draft a customized AI tactical report or Twitter thread matching &quot;{searchQuery}&quot;?</span>
                  </div>
                  <button
                    onClick={() => {
                      setActiveTab("writer");
                    }}
                    className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-3 py-1.5 text-[11px] rounded transition-colors cursor-pointer shrink-0"
                  >
                    Open AI Writer Portal →
                  </button>
                </div>
              )}
              <NewsFeed />
            </div>
          )}
                   {/* TAB 2: AI write studio */}
          {activeTab === "writer" && (
            <div className="space-y-4">
              {!userProfile ? (
                <div className="p-12 text-center bg-[#070707] border border-white/5 rounded-xl space-y-4 max-w-md mx-auto mt-8">
                  <Sparkles className="w-10 h-10 text-blue-500 mx-auto" strokeWidth={1.5} />
                  <h3 className="font-bold text-lg text-white font-display">Authentication Required</h3>
                  <p className="text-[#e5e5e5]/60 text-xs leading-relaxed font-sans">
                    Access to the advanced AI Tweet & Thread generating studio requires a validated sports enthusiast profile. Please sign up or login instantly.
                  </p>
                  <button
                    onClick={() => setIsAuthOpen(true)}
                    className="p-2 px-6 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg cursor-pointer transition-colors shadow-lg shadow-blue-500/10"
                  >
                    Configure Account
                  </button>
                </div>
              ) : (
                <AIWriter />
              )}
            </div>
          )}

          {/* TAB 3: Pricing and Billing */}
          {activeTab === "pricing" && (
            <div className="space-y-8 max-w-4xl mx-auto" id="pricing-workspace">
              <div className="text-center space-y-2">
                <span className="text-blue-400 bg-blue-500/10 text-[10px] font-extrabold uppercase px-3.5 py-1 rounded-full border border-blue-500/20">
                  Upgrade to Premium Tier
                </span>
                <h2 className="text-2xl font-black font-display text-white tracking-tight">
                  Accelerate Your Sports Writing Business
                </h2>
                <p className="text-[#e5e5e5]/60 text-xs max-w-md mx-auto">
                  Subscribe to unlimited sports copy generating power. Support for local payments suitable for Nigeria (₦ Paystack).
                </p>
              </div>

              {/* Plans display grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                {plans.length === 0 ? (
                  <div className="col-span-2 text-center py-12 text-[#e5e5e5]/40 italic">
                    Loading pricing configurations...
                  </div>
                ) : (
                  plans.filter(p => p.status === "active").map(plan => {
                    const isMyPlan = userProfile?.subscriptionId === plan.id && isPremium;
                    const isMonthly = plan.id === "monthly_vip";
                    return (
                      <div 
                        key={plan.id} 
                        className={`p-6 rounded-2xl flex flex-col justify-between relative transition-all duration-300 ${
                          isMyPlan 
                            ? "bg-[#0f0f0f] border-2 border-blue-500 ring-4 ring-blue-500/5" 
                            : isMonthly
                              ? "bg-gradient-to-b from-blue-950/20 to-[#0c0c0c] border border-blue-500/30 hover:border-blue-500/60"
                              : "bg-[#0f0f0f] border border-white/10 hover:border-white/20"
                        }`}
                      >
                        {isMyPlan && (
                          <span className="absolute -top-3 right-5 bg-blue-600 text-white text-[10px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider">
                            Active Package
                          </span>
                        )}

                        <div className="space-y-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="text-lg font-bold font-display text-white">{plan.name}</h4>
                              <p className="text-white/40 text-[10px] mt-0.5">Package Period: {plan.durationDays} Days</p>
                            </div>
                            {isMonthly && (
                              <span className="text-[9px] bg-blue-500/20 text-blue-400 font-bold px-2 py-0.5 rounded uppercase">Highly Popular</span>
                            )}
                          </div>

                          <div className="flex items-baseline gap-1 py-2 border-y border-white/5">
                            <span className="text-2xl font-black text-white font-display">₦{plan.price.toLocaleString()}</span>
                            <span className="text-xs text-white/50 font-medium">/ ₦NGN Net</span>
                          </div>

                          <ul className="space-y-2.5 text-xs text-white/70 pt-2 font-normal">
                            {plan.features.map((feature, idx) => (
                              <li key={idx} className="flex items-start gap-2">
                                <Check className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                                <span>{feature}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="pt-6 shrink-0 mt-4">
                          {!userProfile ? (
                            <button
                              onClick={() => setIsAuthOpen(true)}
                              className="w-full py-2.5 bg-white/5 hover:bg-white/10 text-white border border-white/10 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                            >
                              Login to Unlock Checkout
                            </button>
                          ) : isMyPlan ? (
                            <div className="w-full py-2 px-3 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-center text-xs rounded-xl font-bold flex items-center justify-center gap-1.5">
                              <CheckCircle className="w-4 h-4 text-blue-400" /> Active Expiry: {new Date(userProfile.subscriptionExpiry).toLocaleDateString()}
                            </div>
                          ) : (
                            <button
                              onClick={() => {
                                setSelectedPlan(plan);
                                setIsPaystackOpen(true);
                              }}
                              className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-lg shadow-blue-500/10"
                            >
                              Secure Upgrade with Paystack <ArrowRight className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* TAB 4: Admin controls setting panel */}
          {activeTab === "admin" && (
            <AdminHQ />
          )}

          {/* TAB 5: Saved Items and bookmarks */}
          {activeTab === "saved" && (
            <div className="space-y-6" id="saved-bookmarks-hub">
              <div className="space-y-1 pb-4 border-b border-white/10">
                <h2 className="text-xl font-bold tracking-tight text-white font-display flex items-center gap-2">
                  <Bookmark className="w-5 h-5 text-blue-400" /> Saved Posts & Bookmarks
                </h2>
                <p className="text-white/60 text-xs font-normal font-sans">
                  Read offline and verify transfer reports that you bookmarked on the feed page.
                </p>
              </div>

              {!userProfile ? (
                <div className="p-8 text-center text-white/40 italic text-xs">
                  Please log in to load and manage persistent bookmarks histories.
                </div>
              ) : savedArticles.length === 0 ? (
                <div className="text-center py-16 bg-white/5 border border-dashed border-white/10 rounded-xl space-y-2">
                  <Bookmark className="w-8 h-8 text-white/20 mx-auto" />
                  <h4 className="text-sm font-bold text-white/60 font-display">No Bookmarks Recorded</h4>
                  <p className="text-xs text-white/40">Go to the Sports News tab and tap the &quot;Save&quot; icon to bookmark stories instantly.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {savedArticles.map(article => (
                    <div key={article.id} className="p-5 bg-[#0f0f0f] border border-white/10 rounded-xl flex flex-col justify-between hover:border-white/20 transition-colors">
                      <div className="space-y-2">
                        <span className="text-[10px] uppercase font-bold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded">
                          {article.category}
                        </span>
                        <h3 className="text-sm font-bold text-white mt-1.5 truncate">{article.title}</h3>
                        <p className="text-xs text-white/60 line-clamp-3">{article.summary}</p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between text-[11px]">
                        <span className="text-white/40">{article.source}</span>
                        <button
                          onClick={() => toggleSavePost(article.id)}
                          className="text-rose-400 hover:text-rose-500 font-medium cursor-pointer"
                        >
                          Remove Bookmark
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </main>
      </div>

      {/* 3. FOOTER DETAILS BAR */}
      <footer className="bg-[#0a0a0a] border-t border-white/10 px-4 py-4 flex flex-col sm:flex-row items-center justify-between text-[10px] text-white/40 select-none">
        <p className="font-normal font-sans">© 2026 ApexFootball Media SaaS platform. Fully integrated with Paystack simulated gate and Google Gen AI models.</p>
        <p className="font-mono mt-1.5 sm:mt-0 font-normal">Database Connection Tested • Verified Secure ABAC Controls</p>
      </footer>

      {/* Auth Modal Trigger popup wrapper */}
      <AuthModal 
        isOpen={isAuthOpen} 
        onClose={() => setIsAuthOpen(false)} 
      />

      {/* Paystack Payment Checkout Portal Popup wrapper */}
      <PaystackModal 
        isOpen={isPaystackOpen} 
        onClose={() => setIsPaystackOpen(false)} 
        plan={selectedPlan}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DashboardContent />
    </AuthProvider>
  );
}
