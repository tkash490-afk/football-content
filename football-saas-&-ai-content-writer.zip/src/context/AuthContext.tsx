import React, { createContext, useContext, useState, useEffect } from "react";
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail,
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  User
} from "firebase/auth";
import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  onSnapshot,
  collection,
  query,
  where,
  getDocs
} from "firebase/firestore";
import { auth, db, handleFirestoreError, OperationType } from "../firebase";
import { UserProfile, SubscriptionPlan, AppNotification } from "../types";

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  signUp: (email: string, password: string, name: string) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  updateFavoriteClubs: (clubs: string[]) => Promise<void>;
  toggleSavePost: (postId: string) => Promise<void>;
  incrementGeneration: () => Promise<boolean>;
  setPremiumSubscription: (planId: string, durationDays: number) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within an AuthProvider");
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Monitor Auth Changes
  useEffect(() => {
    let unsubscribeSnapshot: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      // 1. Immediately unsubscribe from any former snapshot listener to prevent leaks and privilege violation errors on auth change
      if (unsubscribeSnapshot) {
        unsubscribeSnapshot();
        unsubscribeSnapshot = null;
      }

      setCurrentUser(user);
      if (user) {
        // Real-time Firestore sync for current user profile
        const userRef = doc(db, "users", user.uid);
        unsubscribeSnapshot = onSnapshot(userRef, async (docSnap) => {
          if (docSnap.exists()) {
            const data = docSnap.data() as UserProfile;
            setUserProfile({
              ...data,
              isAdmin: data.isAdmin || user.email === "stevenjames2852@gmail.com"
            });
          } else {
            // Profile doesn't exist yet, construct initial user profile
            const newProfile: UserProfile = {
              uid: user.uid,
              email: user.email || "",
              name: user.displayName || "Football Enthusiast",
              favoriteClubs: [],
              subscriptionId: "free",
              subscriptionStatus: "inactive",
              subscriptionExpiry: "",
              savedPosts: [],
              dailyGenerationCount: 0,
              lastGenerationDate: new Date().toISOString().split("T")[0],
              createdAt: new Date().toISOString(),
              isAdmin: user.email === "stevenjames2852@gmail.com"
            };
            try {
              await setDoc(userRef, newProfile);
            } catch (err) {
              handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
            }
            setUserProfile(newProfile);
          }
        }, (error) => {
          // Gracefully pipe onSnapshot rule errors to the workspace diagnostic handler
          handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
        });
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => {
      if (unsubscribeSnapshot) {
        unsubscribeSnapshot();
      }
      unsubscribeAuth();
    };
  }, []);

  // Email / Password sign up
  const signUp = async (email: string, password: string, name: string) => {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // Create initial user profile in Firestore
    const userRef = doc(db, "users", user.uid);
    const newProfile: UserProfile = {
      uid: user.uid,
      email: email,
      name: name,
      favoriteClubs: [],
      subscriptionId: "free",
      subscriptionStatus: "inactive",
      subscriptionExpiry: "",
      savedPosts: [],
      dailyGenerationCount: 0,
      lastGenerationDate: new Date().toISOString().split("T")[0],
      createdAt: new Date().toISOString(),
      isAdmin: email === "stevenjames2852@gmail.com"
    };
    try {
      await setDoc(userRef, newProfile);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
    }
  };

  // Email / Password login
  const login = async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, email, password);
  };

  // Google Sign In
  const loginWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
  };

  // Logout
  const logout = async () => {
    await signOut(auth);
  };

  // Password Reset
  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  // Update clubs preferences
  const updateFavoriteClubs = async (clubs: string[]) => {
    if (!currentUser) return;
    const userRef = doc(db, "users", currentUser.uid);
    try {
      await updateDoc(userRef, { favoriteClubs: clubs });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${currentUser.uid}`);
    }
  };

  // Toggle saving a post
  const toggleSavePost = async (postId: string) => {
    if (!currentUser || !userProfile) return;
    const userRef = doc(db, "users", currentUser.uid);
    const saved = userProfile.savedPosts || [];
    let updatedSaved: string[];
    if (saved.includes(postId)) {
      updatedSaved = saved.filter(id => id !== postId);
    } else {
      updatedSaved = [...saved, postId];
    }
    try {
      await updateDoc(userRef, { savedPosts: updatedSaved });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${currentUser.uid}`);
    }
  };

  // Try increments count and check restrictions
  const incrementGeneration = async (): Promise<boolean> => {
    if (!currentUser || !userProfile) return false;
    const userRef = doc(db, "users", currentUser.uid);
    const today = new Date().toISOString().split("T")[0];
    
    const isPremium = userProfile.subscriptionStatus === "active" && 
                      new Date(userProfile.subscriptionExpiry) > new Date();

    let count = userProfile.dailyGenerationCount || 0;
    const lastDate = userProfile.lastGenerationDate;

    if (lastDate !== today) {
      count = 0; // Reset count on a new day
    }

    if (!isPremium && count >= 3) {
      return false; // Limit hit for non-premium
    }

    try {
      await updateDoc(userRef, {
        dailyGenerationCount: count + 1,
        lastGenerationDate: today
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${currentUser.uid}`);
    }
    return true;
  };

  // Upgrade user to premium subscripton plan
  const setPremiumSubscription = async (planId: string, durationDays: number) => {
    if (!currentUser) return;
    const userRef = doc(db, "users", currentUser.uid);
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + durationDays);

    try {
      await updateDoc(userRef, {
        subscriptionId: planId,
        subscriptionStatus: "active",
        subscriptionExpiry: expiryDate.toISOString()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${currentUser.uid}`);
    }
  };

  return (
    <AuthContext.Provider value={{
      currentUser,
      userProfile,
      loading,
      signUp,
      login,
      loginWithGoogle,
      logout,
      resetPassword,
      updateFavoriteClubs,
      toggleSavePost,
      incrementGeneration,
      setPremiumSubscription
    }}>
      {children}
    </AuthContext.Provider>
  );
};
