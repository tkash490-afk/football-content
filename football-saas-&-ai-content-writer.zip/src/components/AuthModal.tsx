import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { LogIn, UserPlus, HelpCircle, Shield, Sparkles } from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { login, signUp, loginWithGoogle, resetPassword } = useAuth();
  const [isSignUp, setIsSignUp] = useState(false);
  const [isForgot, setIsForgot] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (isForgot) {
        if (!email) throw new Error("Please enter your email address.");
        await resetPassword(email);
        setSuccessMsg("Check your inbox for a password reset email!");
      } else if (isSignUp) {
        if (!email || !password || !name) throw new Error("All fields are required.");
        if (password.length < 6) throw new Error("Password must be at least 6 characters.");
        await signUp(email, password, name);
        onClose();
      } else {
        if (!email || !password) throw new Error("Both email and password are required.");
        await login(email, password);
        onClose();
      }
    } catch (err: any) {
      setError(err?.message || "An authentication error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    try {
      await loginWithGoogle();
      onClose();
    } catch (err: any) {
      setError(err?.message || "Google sign-in was canceled.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" id="auth-modal">
      <div className="w-full max-w-md overflow-hidden bg-[#0f0f0f] border border-white/10 rounded-2xl shadow-2xl">
        {/* Banner */}
        <div className="p-6 bg-gradient-to-r from-blue-700 to-blue-900 flex flex-col items-center text-center">
          <div className="p-3 bg-white/10 rounded-full mb-2">
            <Sparkles className="w-7 h-7 text-blue-300" />
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-white font-display">
            ApexFootball AI SaaS
          </h2>
          <p className="text-white/80 text-sm mt-1 font-sans">
            {isForgot 
              ? "Reset your credentials" 
              : isSignUp 
                ? "Join thousands of global sports creators" 
                : "Sign in to your premium sports dashboard"}
          </p>
        </div>

        {/* Content Form */}
        <div className="p-6">
          {error && (
            <div className="p-3 mb-4 text-sm text-rose-400 bg-rose-500/10 border border-rose-500/20 rounded-lg">
              {error}
            </div>
          )}

          {successMsg && (
            <div className="p-3 mb-4 text-sm text-blue-400 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              {successMsg}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && !isForgot && (
              <div>
                <label className="block text-xs font-medium text-white/40 uppercase tracking-wider mb-1.5 font-mono">
                  Display Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Victor Palmer"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#151515] border border-white/5 rounded-lg text-[#e5e5e5] placeholder-white/20 focus:outline-none focus:border-blue-500/55 text-sm transition-colors"
                  required
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-white/40 uppercase tracking-wider mb-1.5 font-mono">
                Email Address
              </label>
              <input
                type="email"
                placeholder="yourname@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-2.5 bg-[#151515] border border-white/5 rounded-lg text-[#e5e5e5] placeholder-white/20 focus:outline-none focus:border-blue-500/55 text-sm transition-colors"
                required
              />
            </div>

            {!isForgot && (
              <div>
                <label className="block text-xs font-medium text-white/40 uppercase tracking-wider mb-1.5 font-mono">
                  Password
                </label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-2.5 bg-[#151515] border border-white/5 rounded-lg text-[#e5e5e5] placeholder-white/20 focus:outline-none focus:border-blue-500/55 text-sm transition-colors"
                  required
                />
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 mt-2 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 disabled:bg-blue-500/50 text-white font-semibold rounded-lg shadow-lg shadow-blue-500/10 transition-colors text-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : isForgot ? (
                "Send Reset Link"
              ) : isSignUp ? (
                <>
                  <UserPlus className="w-4 h-4" /> Create Account
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4" /> Sign In
                </>
              )}
            </button>
          </form>

          {/* Separator */}
          {!isForgot && (
            <>
              <div className="relative my-5 font-sans">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-white/5"></div>
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="px-2 bg-[#0f0f0f] text-white/30 font-mono text-[10px]">Or continue with</span>
                </div>
              </div>

              <button
                onClick={handleGoogleSignIn}
                disabled={loading}
                className="w-full py-2.5 border border-white/10 bg-[#151515] hover:bg-white/5 text-white/95 font-medium rounded-lg text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <svg className="w-4 h-4 mr-1" viewBox="0 0 24 24">
                  <path
                    fill="#EA4335"
                    d="M12.24 10.285V14.4h6.887c-.275 1.565-1.88 4.604-6.887 4.604-4.33 0-7.859-3.578-7.859-8s3.53-8 7.859-8c2.46 0 4.105 1.025 5.047 1.926l3.258-3.133C18.337 1.808 15.549 1 12.24 1 5.922 1 1 5.922 1 12s4.922 11 11.24 11c6.592 0 11.002-4.604 11.002-11.18 0-.751-.082-1.326-.183-1.815V10.285H12.24z"
                  />
                </svg>
                Google Credentials
              </button>
            </>
          )}

          {/* Footer Navigation */}
          <div className="mt-6 flex justify-between text-xs text-white/60 font-sans">
            {isForgot ? (
              <button onClick={() => setIsForgot(false)} className="hover:text-blue-400 font-medium ml-auto cursor-pointer transition-colors">
                Back to Login
              </button>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => {
                    setIsSignUp(!isSignUp);
                    setError(null);
                    setSuccessMsg(null);
                  }}
                  className="hover:text-blue-400 font-bold transition-colors cursor-pointer"
                >
                  {isSignUp ? "Already have an account? Sign In" : "Need an account? Sign Up"}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsForgot(true);
                    setError(null);
                    setSuccessMsg(null);
                  }}
                  className="hover:text-blue-400 font-bold flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <HelpCircle className="w-3 h-3" /> Forgot Password?
                </button>
              </>
            )}
          </div>

          {/* Email verification note */}
          <div className="mt-8 pt-4 border-t border-white/5 flex items-start gap-2.5 text-xs text-white/30 font-sans">
            <Shield className="w-4 h-4 text-white/40 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              Note: Email signups dynamically simulate and prompt verify on the dashboard. To fully complete Email Verification via Firebase Auth, toggle the email provider live inside your console.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
