import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { 
  Sparkles, FileText, Send, RefreshCw, Copy, Check, 
  Trash2, AlertTriangle, Crown, Calendar, Feather,
  BookOpen, HelpCircle
} from "lucide-react";
import { db, handleFirestoreError, OperationType } from "../firebase";
import { 
  collection, 
  setDoc, 
  query, 
  where, 
  getDocs, 
  orderBy, 
  limit,
  doc, 
  deleteDoc 
} from "firebase/firestore";
import { GeneratedContent } from "../types";

export const AIWriter: React.FC = () => {
  const { userProfile, incrementGeneration } = useAuth();
  
  const [prompt, setPrompt] = useState("");
  const [type, setType] = useState<"tweet" | "thread" | "analysis">("tweet");
  const [tone, setTone] = useState("Professional");
  const [additionalContext, setAdditionalContext] = useState("");
  
  // Advanced settings (Premium Only)
  const [temperature, setTemperature] = useState(0.85);
  const [includeStats, setIncludeStats] = useState(true);

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState("");
  const [copied, setCopied] = useState(false);
  const [history, setHistory] = useState<GeneratedContent[]>([]);

  // Limits check parameters
  const isPremium = userProfile?.subscriptionStatus === "active" && 
                    new Date(userProfile?.subscriptionExpiry || "") > new Date();
  
  const remainingGenerations = isPremium ? "Unlimited" : Math.max(0, 3 - (userProfile?.dailyGenerationCount || 0));

  // Load Content History from Firestore
  const fetchHistory = async () => {
    if (!userProfile?.uid) return;
    try {
      const q = query(
        collection(db, "generatedContents"),
        where("userId", "==", userProfile.uid),
        orderBy("createdAt", "desc"),
        limit(15)
      );
      const querySnap = await getDocs(q);
      const items: GeneratedContent[] = [];
      querySnap.forEach(docSnap => {
        items.push({ id: docSnap.id, ...docSnap.data() } as GeneratedContent);
      });
      setHistory(items);
    } catch (err) {
      console.warn("Failed to load historical content list:", err);
      handleFirestoreError(err, OperationType.GET, "generatedContents");
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [userProfile?.uid, result]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setLoading(true);
    setResult("");

    try {
      // 1. Try to increment user's daily count and check limits
      const permitted = await incrementGeneration();
      if (!permitted) {
        throw new Error("Daily content generation limit reached. Upgrade to Premium for unlimited writes!");
      }

      // 2. Post to custom proxy API Route keep GEMINI_API_KEY safe
      const response = await fetch("/api/gemini/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          type,
          tone,
          additionalContext: additionalContext + (includeStats ? " (Include relevant statistics and goal records if known)" : ""),
          isPremium
        })
      });

      const resData = await response.json();
      if (!resData.success) throw new Error(resData.error || "Generation error");

      setResult(resData.text);

      // 3. Save generation record to Firestore `/generatedContents`
      if (userProfile?.uid) {
        const contentId = "gen_" + Date.now() + "_" + Math.random().toString(36).substring(2, 9);
        try {
          await setDoc(doc(db, "generatedContents", contentId), {
            id: contentId,
            userId: userProfile.uid,
            prompt,
            result: resData.text,
            type,
            createdAt: new Date().toISOString()
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, "generatedContents/" + contentId);
        }
      }

    } catch (err: any) {
      alert(err.message || "An error occurred during content generation.");
    } finally {
      setLoading(false);
    }
  };

  const deleteHistoryItem = async (id: string) => {
    try {
      await deleteDoc(doc(db, "generatedContents", id));
      setHistory(prev => prev.filter(item => item.id !== id));
    } catch (err) {
      console.error("Failed to delete item:", err);
      handleFirestoreError(err, OperationType.DELETE, "generatedContents/" + id);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(result || "");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="ai-writer-root">
      
      {/* Parameters & Configuration Box */}
      <div className="lg:col-span-1 space-y-5">
        
        {/* Limits Warning card for Free users */}
        <div className={`p-4 rounded-xl border flex gap-3 text-xs font-semibold ${
          isPremium 
            ? "bg-blue-500/5 border-blue-500/20 text-blue-400" 
            : "bg-amber-500/5 border-amber-500/20 text-amber-300"
        }`}>
          {isPremium ? (
            <>
              <Crown className="w-5 h-5 text-amber-400 shrink-0" />
              <div>
                <p className="font-extrabold text-white">Premium Creator Plan Active</p>
                <p className="font-normal text-white/60 mt-0.5">Unlimited AI content writes, Threads, and match analytics unlocked.</p>
              </div>
            </>
          ) : (
            <>
              <AlertTriangle className="w-5 h-5 text-amber-505 shrink-0" />
              <div>
                <p className="font-extrabold text-white">Free Content Plan Limits</p>
                <p className="font-normal text-white/50 mt-0.5 font-sans">
                  Remaining today: <span className="text-amber-305 font-bold font-mono">{remainingGenerations}</span>
                </p>
                <p className="font-normal text-white/50 font-sans">Upgrade to Premium for unlimited thread generation and priority engines.</p>
              </div>
            </>
          )}
        </div>

        {/* Input Parameters Form */}
        <div className="p-5 bg-[#0f0f0f] border border-white/10 rounded-xl space-y-4">
          <h3 className="text-sm font-extrabold text-white uppercase tracking-wider flex items-center gap-2 font-display">
            <Feather className="w-4 h-4 text-blue-400" /> Generation Settings
          </h3>

          <form onSubmit={handleGenerate} className="space-y-4">
            
            {/* Format Type */}
            <div>
              <label className="block text-xs text-white/40 font-bold mb-1.5 uppercase font-mono tracking-wider">Content Format</label>
              <div className="grid grid-cols-3 gap-2">
                {(["tweet", "thread", "analysis"] as const).map(f => {
                  const locked = f === "thread" && !isPremium;
                  return (
                    <button
                      key={f}
                      type="button"
                      disabled={locked}
                      onClick={() => setType(f)}
                      className={`py-2.5 text-xs font-semibold rounded-lg border flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                        type === f 
                          ? "bg-blue-500/10 text-blue-400 border-blue-500/40" 
                          : "bg-[#151515] text-white/60 border-white/10 hover:border-white/20 hover:text-white"
                      } ${locked ? "opacity-30 cursor-not-allowed" : ""}`}
                    >
                      {f === "tweet" && <Send className="w-3.5 h-3.5" />}
                      {f === "thread" && <BookOpen className="w-3.5 h-3.5" />}
                      {f === "analysis" && <FileText className="w-3.5 h-3.5" />}
                      <span className="capitalize">{f === "analysis" ? "Report" : f}</span>
                    </button>
                  );
                })}
              </div>
              {!isPremium && <p className="text-[10px] text-white/45 mt-1 text-amber-400">🔒 Threads are premium exclusive.</p>}
            </div>

            {/* Prompt */}
            <div>
              <label className="block text-xs text-white/40 font-bold mb-1.5 uppercase font-mono tracking-wider">Prompt Details</label>
              <textarea
                placeholder="e.g. Write a tactical analysis of Cole Palmer's performance as a false nine under Enzo Maresca, mentioning Chelsea's win."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                rows={4}
                className="w-full px-3 py-2.5 bg-[#151515] border border-white/5 focus:border-blue-500/50 text-[#e5e5e5] placeholder-white/30 focus:outline-none rounded-lg text-xs font-sans leading-relaxed transition-colors"
                required
              />
            </div>

            {/* Tone Selector */}
            <div>
              <label className="block text-xs text-white/40 font-bold mb-1.5 uppercase font-mono tracking-wider">Tone Variation</label>
              <select
                value={tone}
                onChange={(e) => setTone(e.target.value)}
                className="w-full px-3 py-2 bg-[#151515] border border-white/5 focus:border-blue-500/50 text-[#e5e5e5] focus:outline-none rounded-lg text-xs transition-colors cursor-pointer"
              >
                <option>Professional Sports Journalism</option>
                <option>Excited & Hype Influencer</option>
                <option>Deeply Tactical & Analytical</option>
                <option>Brutally Biased Club Supporter</option>
                <option>Controversial Debate Hook</option>
              </select>
            </div>

            {/* Short tags context */}
            <div>
              <label className="block text-xs text-white/40 font-bold mb-1.5 uppercase font-mono tracking-wider">Tags &amp; Context</label>
              <input
                type="text"
                placeholder="e.g. #CFC, Palmer, Maresca"
                value={additionalContext}
                onChange={(e) => setAdditionalContext(e.target.value)}
                className="w-full px-3 py-2.5 bg-[#151515] border border-white/5 focus:border-blue-500/50 text-[#e5e5e5] placeholder-white/30 focus:outline-none rounded-lg text-xs font-sans transition-colors"
              />
            </div>

            {/* Premium Only Configurations */}
            <div className={`pt-3 border-t border-white/5 space-y-3 ${!isPremium ? "opacity-40 pointer-events-none select-none" : ""}`}>
              <div className="flex items-center justify-between text-xs font-bold text-white/40 font-mono">
                <span>ADVANCED SETTINGS</span>
                {!isPremium && <span className="text-[10px] text-amber-450 font-bold flex items-center gap-1 uppercase"><Crown className="w-3.5 h-3.5 text-amber-500" /> Premium VIP</span>}
              </div>

              <div>
                <div className="flex justify-between text-[11px] text-white/60 mb-1 font-mono">
                  <span>Temperature (Creativity)</span>
                  <span>{temperature}</span>
                </div>
                <input
                  type="range"
                  min="0.3"
                  max="1.0"
                  step="0.05"
                  value={temperature}
                  onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="w-full h-1 bg-[#151515] rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
              </div>

              <label className="flex items-center gap-2.5 text-xs text-white/60 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={includeStats}
                  onChange={(e) => setIncludeStats(e.target.checked)}
                  className="rounded border-white/10 text-blue-500 bg-[#151515] focus:ring-blue-500/20 cursor-pointer accent-blue-600"
                />
                <span className="font-sans">Include sports facts &amp; statistics</span>
              </label>
            </div>

            {/* Submit Trigger */}
            <button
              type="submit"
              disabled={loading || prompt.trim() === ""}
              className="w-full py-2.5 mt-2 bg-blue-600 hover:bg-blue-500 disabled:bg-white/5 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 cursor-pointer disabled:cursor-not-allowed"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Sparkles className="w-4 h-4" /> Trigger AI Content Generator
                </>
              )}
            </button>
          </form>
        </div>
      </div>

      {/* Editor & Generated Output Screen */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Main Result display card */}
        <div className="p-5 bg-[#0f0f0f] border border-white/10 rounded-xl min-h-[360px] flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <span className="text-xs text-white/50 font-bold flex items-center gap-1.5 font-mono uppercase tracking-wider">
                <Feather className="w-4 h-4 text-blue-400" /> Live AI Copier Pad
              </span>
              {result && (
                <button
                  onClick={copyToClipboard}
                  className="text-xs bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-lg text-white flex items-center gap-1.5 cursor-pointer border border-white/10 font-bold transition-colors"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-blue-400" /> Copied Text
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" /> Quick Copy
                    </>
                  )}
                </button>
              )}
            </div>

            {loading ? (
              <div className="flex flex-col items-center justify-center py-20 space-y-4">
                <RefreshCw className="w-8 h-8 text-blue-500 animate-spin" />
                <div className="text-center space-y-1">
                  <p className="text-xs font-bold text-slate-205">Formulating Football Analytics Copy...</p>
                  <p className="text-[10px] text-white/40">Injecting key player stats and formatting variations...</p>
                </div>
              </div>
            ) : result ? (
              <div className="text-sm text-[#e5e5e5] overflow-y-auto whitespace-pre-wrap font-sans leading-relaxed max-h-[380px] p-2 bg-[#151515]/30 rounded-lg selection:bg-blue-500/20 select-text">
                {result}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-20 text-white/20 text-center space-y-2">
                <Sparkles className="w-8 h-8 text-white/15" />
                <p className="text-xs font-semibold text-white/50">Your generated post will appear here</p>
                <p className="text-[10px] text-white/30 max-w-xs font-sans leading-relaxed">Enter your prompt on the left and trigger the AI copy block in single or thread variations.</p>
              </div>
            )}
          </div>

          {result && (
            <div className="mt-6 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-white/40">
              <span className="font-mono">Estimated scale: {result.length} characters</span>
              <span className="font-mono">Inference Engine: Gemini API Flash</span>
            </div>
          )}
        </div>

        {/* Content History Shelf (A key request!) */}
        {userProfile && (
          <div className="p-5 bg-[#0f0f0f] border border-white/10 rounded-xl space-y-4">
            <h3 className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-1.5 font-mono">
              <Calendar className="w-4 h-4 text-blue-400" /> Generated Content History
            </h3>

            {history.length === 0 ? (
              <p className="text-xs text-white/40 italic py-4 text-center select-none font-sans">
                Your historical AI creations will be recorded securely here.
              </p>
            ) : (
              <div className="space-y-3.5 max-h-[260px] overflow-y-auto pr-1">
                {history.map(item => (
                  <div key={item.id} className="p-4 bg-[#151515]/55 border border-white/5 rounded-xl flex justify-between gap-4 group hover:border-white/10 transition-colors">
                    <div className="space-y-1.5 my-auto max-w-[85%] select-text">
                      <div className="flex items-center gap-2 text-[10px] text-white/45 font-mono">
                        <span className="uppercase font-bold tracking-brand text-blue-400">
                          {item.type}
                        </span>
                        <span>•</span>
                        <span>{new Date(item.createdAt).toLocaleDateString()}</span>
                      </div>
                      <p className="text-[11px] font-semibold text-white/60 italic truncate">
                        &quot;{item.prompt}&quot;
                      </p>
                      <p className="text-xs text-[#e5e5e5]/80 line-clamp-2 mt-1">
                        {item.result}
                      </p>
                    </div>
                    <div className="flex flex-col justify-between shrink-0 select-none">
                      <button
                        onClick={() => {
                          setResult(item.result);
                          setPrompt(item.prompt);
                          setType(item.type);
                        }}
                        className="text-[10px] bg-white/5 hover:bg-white/10 font-bold px-2.5 py-1.5 border border-white/10 rounded-lg text-white cursor-pointer text-center transition-colors"
                      >
                        Reuse
                      </button>
                      <button
                        onClick={() => deleteHistoryItem(item.id)}
                        className="p-1 text-white/20 hover:text-rose-400 transition-colors mt-2 mx-auto cursor-pointer"
                        title="Delete record"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
