import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { CreditCard, CheckCircle2, Lock, ArrowRight, ShieldCheck, HelpCircle } from "lucide-react";
import { db } from "../firebase";
import { doc, setDoc } from "firebase/firestore";
import { SubscriptionPlan } from "../types";

interface PaystackModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: SubscriptionPlan | null;
}

export const PaystackModal: React.FC<PaystackModalProps> = ({ isOpen, onClose, plan }) => {
  const { userProfile, setPremiumSubscription } = useAuth();
  const [step, setStep] = useState<"details" | "otp" | "success">("details");
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [pin, setPin] = useState("");
  const [otp, setOtp] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [paymentRef, setPaymentRef] = useState("");

  if (!isOpen || !plan) return null;

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, "");
    if (val.length > 16) val = val.substring(0, 16);
    // Format card with spaces: 4444 4444 4444 4444
    const matches = val.match(/\d{4,16}/g);
    let formatted = "";
    if (matches) {
       const parts = [];
       for (let i = 0; i < val.length; i += 4) {
         parts.push(val.substring(i, i + 4));
       }
       formatted = parts.join(" ");
    } else {
       formatted = val;
    }
    setCardNumber(formatted);
  };

  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, "");
    if (val.length > 4) val = val.substring(0, 4);
    if (val.length > 2) {
      val = val.substring(0, 2) + "/" + val.substring(2);
    }
    setExpiry(val);
  };

  const handleCvvChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, "");
    if (val.length <= 3) setCvv(val);
  };

  const handlePinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\D/g, "");
    if (val.length <= 4) setPin(val);
  };

  const startPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (cardNumber.length < 15 || expiry.length < 5 || cvv.length < 3 || pin.length < 4) {
      setError("Please complete all card credentials details.");
      return;
    }
    setLoading(true);

    try {
      // Call server initialization
      const response = await fetch("/api/paystack/initialize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: userProfile?.email || "anonymous@gmail.com",
          amount: plan.price * 100, // Kobo conversion
          planId: plan.id,
          name: userProfile?.name || ""
        })
      });
      const resData = await response.json();
      if (!resData.success) throw new Error(resData.error || "Initialization failed");

      setPaymentRef(resData.data.reference);
      
      // Simulate bank redirect delays
      setTimeout(() => {
        setStep("otp");
        setLoading(false);
      }, 1200);

    } catch (err: any) {
      setError(err?.message || "Could not connect to payment gateway.");
      setLoading(false);
    }
  };

  const submitOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!otp) {
      setError("Please enter the 6-digit transaction PIN/OTP code.");
      return;
    }
    setLoading(true);

    try {
      // Call server verify API
      const result = await fetch("/api/paystack/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reference: paymentRef, amount: plan.price * 100 })
      });
      const resData = await result.json();
      if (!resData.success) throw new Error(resData.error || "Verification failed");

      // Transaction succeeds! Let's write user subscription state securely using AuthContext helper
      await setPremiumSubscription(plan.id, plan.durationDays);

      // Create transaction log document entry in `/subscriptions/{reference}` to record invoice
      const paymentLogRef = doc(db, "subscriptions", paymentRef);
      await setDoc(paymentLogRef, {
        id: paymentRef,
        userId: userProfile?.uid || "guest",
        planId: plan.id,
        amount: plan.price,
        status: "success",
        reference: paymentRef,
        startDate: new Date().toISOString(),
        expiryDate: new Date(Date.now() + plan.durationDays * 24 * 60 * 60 * 1000).toISOString(),
        createdAt: new Date().toISOString()
      });

      // Show success
      setStep("success");
    } catch (err: any) {
      setError(err?.message || "OTP verification failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md" id="paystack-modal">
      <div className="w-full max-w-sm bg-[#0f0f0f] border border-white/10 text-[#e5e5e5] overflow-hidden rounded-2xl shadow-2xl font-sans">
        
        {/* Header Branding (Matches Paystack's clean layout in dark mode scheme) */}
        <div className="p-4 bg-[#151515] text-[#3bb75e] flex items-center justify-between border-b border-white/5">
          <div className="flex items-center gap-2 select-none">
            <span className="w-2.5 h-2.5 rounded-full bg-[#3bb75e] animate-pulse" />
            <h3 className="font-semibold text-xs uppercase tracking-widest font-mono text-white">
              Secured by <span className="text-[#3bb75e] font-extrabold font-display lowercase text-sm">paystack</span>
            </h3>
          </div>
          <span className="text-[10px] bg-[#3bb75e]/10 text-[#3bb75e] font-extrabold uppercase px-2 py-0.5 rounded tracking-wide font-mono">
            ₦ NGN
          </span>
        </div>

        {/* Amount bar */}
        <div className="px-5 py-4 bg-[#151515]/55 border-b border-white/5 flex justify-between items-center text-xs">
          <div>
            <p className="text-[10px] text-white/40 font-mono uppercase tracking-wider">Paying to</p>
            <p className="font-semibold text-white mt-0.5">ApexFootball Media SaaS</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] text-white/40 font-mono uppercase tracking-wider">Plan Amount</p>
            <p className="font-extrabold text-blue-400 font-display text-base mt-0.5">
              ₦{plan.price.toLocaleString()}
            </p>
          </div>
        </div>

        {/* Content body based on steps */}
        <div className="p-5">
          {error && (
            <div className="p-3 mb-4 text-xs text-rose-400 bg-rose-500/10 border border-rose-500/20 rounded-lg font-medium flex items-center gap-2">
              <span>⚠️</span>
              <span>{error}</span>
            </div>
          )}

          {step === "details" && (
            <form onSubmit={startPayment} className="space-y-4 font-sans">
              <div>
                <label className="block text-[10px] font-bold text-white/45 mb-1.5 uppercase font-mono tracking-wider">
                  Card Number
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-white/30">
                    <CreditCard className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    placeholder="4012 8831 9904 2251"
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    className="w-full pl-10 pr-4 py-2 bg-[#151515] border border-white/5 focus:bg-[#151515] focus:outline-none focus:border-[#3bb75e]/60 text-white placeholder-white/20 rounded-lg text-xs font-mono tracking-wider"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-white/45 mb-1.5 uppercase font-mono tracking-wider">
                    Card Expiry
                  </label>
                  <input
                    type="text"
                    placeholder="MM/YY"
                    value={expiry}
                    onChange={handleExpiryChange}
                    className="w-full px-4 py-2 bg-[#151515] border border-white/5 focus:bg-[#151515] focus:outline-none focus:border-[#3bb75e]/60 text-white placeholder-white/20 rounded-lg text-xs font-mono tracking-wider text-center"
                    required
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-white/45 mb-1.5 uppercase font-mono tracking-wider">
                    CVV Code
                  </label>
                  <input
                    type="password"
                    placeholder="123"
                    value={cvv}
                    onChange={handleCvvChange}
                    className="w-full px-4 py-2 bg-[#151515] border border-white/5 focus:bg-[#151515] focus:outline-none focus:border-[#3bb75e]/60 text-white placeholder-white/20 rounded-lg text-xs font-mono tracking-wider text-center"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-white/45 mb-1.5 uppercase font-mono tracking-wider flex items-center justify-between">
                  <span>Card ATM PIN</span>
                  <span className="text-[9px] text-white/30 font-light lowercase">(required for auth)</span>
                </label>
                <input
                  type="password"
                  placeholder="••••"
                  value={pin}
                  onChange={handlePinChange}
                  className="w-full px-4 py-2 bg-[#151515] border border-[#ffffff0a] focus:bg-[#151515] focus:outline-none focus:border-[#3bb75e]/60 text-white placeholder-white/20 rounded-lg text-xs font-mono tracking-wider text-center"
                  maxLength={4}
                  required
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full mt-4 py-2.5 bg-[#3bb75e] hover:bg-[#329e50] active:bg-[#288141] disabled:opacity-40 text-white font-extrabold text-xs tracking-wider uppercase rounded-lg transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-emerald-500/10"
              >
                {loading ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    Pay ₦{plan.price.toLocaleString()} <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>

              <p className="text-[10px] text-white/35 text-center flex items-center justify-center gap-1.5 mt-2 font-mono">
                <Lock className="w-3 h-3 text-[#3bb75e] shrink-0" /> Secured connection. Sandbox mode active.
              </p>
            </form>
          )}

          {step === "otp" && (
            <form onSubmit={submitOtp} className="space-y-4 font-sans">
              <div className="p-4 bg-blue-500/10 rounded-xl border border-blue-500/20 flex gap-3 text-xs text-blue-400 leading-normal">
                <ShieldCheck className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-extrabold uppercase font-mono text-[10px]">OTP Code Sent</p>
                  <p className="mt-1 text-white/70 font-sans normal-case">Enter the mock OTP token code below. (Any 6 numbers will pass safely in this simulation).</p>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-white/45 text-center mb-2 uppercase tracking-wider font-mono">
                  Enter 6-Digit OTP
                </label>
                <input
                  type="text"
                  placeholder="123456"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").substring(0, 6))}
                  className="w-full max-w-[170px] mx-auto px-4 py-2 bg-[#151515] border border-white/5 focus:bg-[#151515] focus:outline-none focus:border-[#3bb75e]/60 text-white placeholder-white/20 rounded-lg text-xs text-center font-mono font-bold tracking-widest"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-[#3bb75e] hover:bg-[#329e50] active:bg-[#288141] disabled:opacity-40 text-white font-extrabold text-xs tracking-wider uppercase rounded-lg transition-all flex items-center justify-center cursor-pointer"
              >
                {loading ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  "Authorize & Verify"
                )}
              </button>

              <button
                type="button"
                onClick={() => setStep("details")}
                className="w-full py-1 text-[10px] text-white/50 hover:text-white text-center font-mono cursor-pointer transition-colors"
              >
                Cancel and edit card details
              </button>
            </form>
          )}

          {step === "success" && (
            <div className="text-center py-6 space-y-4">
              <div className="mx-auto w-12 h-12 bg-blue-500/10 rounded-full flex items-center justify-center text-blue-400 border border-blue-500/20">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="font-sans">
                <h4 className="text-lg font-bold text-white font-display">Payment Successful!</h4>
                <p className="text-xs text-white/60 mt-1.5 leading-relaxed">
                  You are now upgraded to the <span className="font-bold text-white font-mono uppercase tracking-wide bg-blue-500/10 border border-blue-500/20 px-1.5 py-0.5 rounded text-[10px]">{plan.name}</span>.
                </p>
                <div className="mt-4 p-4 bg-[#151515] border border-white/5 rounded-xl text-white/45 text-left space-y-1.5 font-mono text-[10px] max-w-[280px] mx-auto leading-relaxed">
                  <p>Ref: <span className="text-white/80">{paymentRef}</span></p>
                  <p>Gateway: <span className="text-white/80">Paystack Sandbox</span></p>
                  <p>Duration: <span className="text-white/80">{plan.durationDays} Days</span></p>
                </div>
              </div>
              <button
                onClick={() => {
                  onClose();
                  // Reset modal state
                  setStep("details");
                  setCardNumber("");
                  setExpiry("");
                  setCvv("");
                  setPin("");
                  setOtp("");
                }}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold rounded-lg shadow cursor-pointer transition-colors"
              >
                Retrieve Premium Dashboard
              </button>
            </div>
          )}
        </div>

        {/* Footer info links */}
        <div className="px-5 py-2 bg-[#151515] border-t border-white/5 flex items-center justify-between text-[9px] text-white/30 font-sans select-none">
          <span className="flex items-center gap-1"><HelpCircle className="w-3 h-3 text-white/30" /> Need Help? Integration Contact</span>
          <span>Terms & Safety info</span>
        </div>
      </div>
    </div>
  );
};
