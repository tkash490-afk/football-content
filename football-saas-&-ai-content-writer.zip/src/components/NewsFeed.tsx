import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { FootballNews } from "../types";
import { 
  Search, Star, Bookmark, 
  TrendingUp, RefreshCw, Zap, Award, HelpCircle, 
  Sparkles, FileText, Activity 
} from "lucide-react";
import { db } from "../firebase";
import { doc, updateDoc } from "firebase/firestore";

const CLUBS_LIST = [
  "Chelsea", "Arsenal", "Liverpool", "Manchester United", 
  "Barcelona", "Real Madrid", "Bayern Munich", "Manchester City", "AC Milan"
];

export const NewsFeed: React.FC = () => {
  const { userProfile, toggleSavePost, updateFavoriteClubs } = useAuth();
  const [news, setNews] = useState<FootballNews[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [favoriteOnly, setFavoriteOnly] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [showFavoritesEditor, setShowFavoritesEditor] = useState(false);

  // Load news from server
  const fetchNews = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/news");
      const resData = await response.json();
      if (resData.success && resData.news) {
        setNews(resData.news);
      }
    } catch (err) {
      console.error("Error loaded news:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNews();
  }, []);

  const handleToggleFavoriteClub = async (club: string) => {
    if (!userProfile) return;
    const current = userProfile.favoriteClubs || [];
    let updated: string[];
    if (current.includes(club)) {
      updated = current.filter(c => c !== club);
    } else {
      updated = [...current, club];
    }
    await updateFavoriteClubs(updated);
  };

  // Smart Sorting Algorithm: prioritizes user's favorite clubs FIRST, then sorts by trending weight (points)
  const processNews = () => {
    let filtered = [...news];

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(item => 
        item.title.toLowerCase().includes(q) ||
        item.summary.toLowerCase().includes(q) ||
        item.clubs.some(c => c.toLowerCase().includes(q)) ||
        item.players.some(p => p.toLowerCase().includes(q)) ||
        (item.content && item.content.toLowerCase().includes(q))
      );
    }

    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter(item => item.category === selectedCategory);
    }

    // Sort: favorites club match goes first, then sorted by trending points descending
    const favorites = userProfile?.favoriteClubs || [];
    filtered.sort((a, b) => {
      const aHasFav = a.clubs.some(c => favorites.includes(c));
      const bHasFav = b.clubs.some(c => favorites.includes(c));
      
      if (aHasFav && !bHasFav) return -1;
      if (!aHasFav && bHasFav) return 1;
      
      return b.points - a.points; // default sort by descending trending points
    });

    if (favoriteOnly && favorites.length > 0) {
      filtered = filtered.filter(item => item.clubs.some(c => favorites.includes(c)));
    }

    return filtered;
  };

  const getCategoryBadgeColor = (cat: string) => {
    switch (cat) {
      case "transfer": return "bg-amber-500/10 text-amber-400 border border-amber-500/20";
      case "confirmed_transfer": return "bg-blue-500/10 text-blue-400 border border-blue-500/20";
      case "manager_sacking": return "bg-rose-500/10 text-rose-400 border border-rose-500/20";
      case "injury": return "bg-purple-500/10 text-purple-400 border border-purple-500/20";
      case "match_result": return "bg-blue-500/10 text-blue-400 border border-blue-500/20";
      default: return "bg-slate-500/10 text-slate-400 border border-slate-500/20";
    }
  };

  const getCategoryEmojiPrefix = (cat: string) => {
    switch (cat) {
      case "confirmed_transfer": return "🤝";
      case "transfer": return "💬";
      case "manager_sacking": return "🚨";
      case "injury": return "🤕";
      case "match_result": return "🏆";
      default: return "⚽";
    }
  };

  const processedNewsItems = processNews();

  return (
    <div className="space-y-6" id="news-feed-root">
      
      {/* Banner / Header Segment with Search */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-[#0f0f0f] border border-white/5 rounded-xl">
        <div className="space-y-1">
          <h2 className="text-xl font-bold tracking-tight text-white font-display flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-400" /> Smart Football News Feed
          </h2>
          <p className="text-white/60 text-xs">
            Aggregated global news and player movements. Prioritized by your favorite clubs first.
          </p>
        </div>
        
        {/* Global Search Bar */}
        <div className="relative w-full md:max-w-md">
          <span className="absolute left-3.5 top-3 text-white/40">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            placeholder="Search Chelsea, Rashford, transfers, injuries..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-[#151515] border border-white/10 rounded-lg text-white placeholder-white/40 focus:outline-none focus:border-blue-500/50 text-sm font-sans"
          />
        </div>
      </div>

      {/* Favorite Clubs Manager Section */}
      {userProfile && (
        <div className="p-4 bg-white/5 border border-white/10 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-medium text-white/70">
              <Star className="w-4 h-4 text-yellow-405 fill-yellow-500/20" />
              <span>Your Favorite Clubs:</span>
              <div className="flex flex-wrap gap-1.5 ml-2">
                {userProfile.favoriteClubs?.length === 0 ? (
                  <span className="text-white/40 text-xs italic">No clubs selected</span>
                ) : (
                  userProfile.favoriteClubs?.map(club => (
                    <span key={club} className="px-2.5 py-0.5 text-xs bg-white/5 border border-white/10 rounded-full text-white/80 font-semibold flex items-center gap-1">
                      {club}
                      <button onClick={() => handleToggleFavoriteClub(club)} className="text-rose-450 hover:text-rose-500 font-extrabold ml-1 cursor-pointer">
                        ×
                      </button>
                    </span>
                  ))
                )}
              </div>
            </div>
            <button
              onClick={() => setShowFavoritesEditor(!showFavoritesEditor)}
              className="text-xs bg-white/5 hover:bg-white/10 text-white border border-white/10 font-medium px-3 py-1 rounded-lg cursor-pointer"
            >
              {showFavoritesEditor ? "Hide Panel" : "Edit Favorites"}
            </button>
          </div>

          {showFavoritesEditor && (
            <div className="pt-2 border-t border-white/10">
              <p className="text-xs text-white/60 mb-2">Select clubs to prioritize their stories automatically:</p>
              <div className="flex flex-wrap gap-2">
                {CLUBS_LIST.map(club => {
                  const isFav = userProfile.favoriteClubs?.includes(club);
                  return (
                    <button
                      key={club}
                      onClick={() => handleToggleFavoriteClub(club)}
                      className={`px-3 py-1 text-xs rounded-full cursor-pointer border transition-colors ${
                        isFav 
                          ? "bg-blue-500/20 text-blue-300 border-blue-500/40" 
                          : "bg-[#0f0f0f] text-white/50 border-white/10 hover:border-white/20 hover:text-white"
                      }`}
                    >
                      {club}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Filter Category Pills */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          {["all", "transfer", "confirmed_transfer", "match_result", "manager_sacking", "injury"].map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg border cursor-pointer transition-colors ${
                selectedCategory === cat
                  ? "bg-blue-500/10 text-blue-400 border-blue-500/30 font-bold"
                  : "bg-[#0f0f0f] text-white/60 border-white/10 hover:border-white/20 hover:text-white"
              }`}
            >
              {cat === "all" ? "All Stories" : cat.toUpperCase().replace("_", " ")}
            </button>
          ))}
        </div>

        {userProfile && userProfile.favoriteClubs && userProfile.favoriteClubs.length > 0 && (
          <label className="flex items-center gap-2 text-xs text-white/60 font-medium cursor-pointer">
            <input
              type="checkbox"
              checked={favoriteOnly}
              onChange={(e) => setFavoriteOnly(e.target.checked)}
              className="rounded border-white/10 text-blue-500 focus:ring-blue-500/30 bg-[#151515] font-semibold cursor-pointer accent-blue-600"
            />
            Show favorite clubs only
          </label>
        )}
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-16 space-y-3">
          <RefreshCw className="w-8 h-8 text-blue-500 animate-spin" />
          <p className="text-xs text-white/50">Compiling latest European sports news feeds...</p>
        </div>
      ) : processedNewsItems.length === 0 ? (
        <div className="text-center py-16 bg-white/5 border border-dashed border-white/10 rounded-xl space-y-2">
          <Search className="w-10 h-10 text-white/20 mx-auto" />
          <h4 className="text-base font-bold text-white/60 font-display">No Matches Found</h4>
          <p className="text-xs text-white/40 max-w-sm mx-auto">
            Try adjusting your search query or selection filters to find relevant football news stories.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {processedNewsItems.map((article) => {
            const isFavOwned = article.clubs.some(c => userProfile?.favoriteClubs?.includes(c));
            const isBookmarked = userProfile?.savedPosts?.includes(article.id);

            return (
              <div 
                key={article.id} 
                className={`flex flex-col overflow-hidden bg-[#0f0f0f] border rounded-xl hover:border-white/20 transition-all cursor-pointer relative ${
                  isFavOwned ? "border-blue-500/30 ring-1 ring-blue-500/5 shadow-md shadow-blue-550/5" : "border-white/10"
                }`}
              >
                {/* Ribbon decoration for favorite club */}
                {isFavOwned && (
                  <div className="absolute top-3 left-3 z-10 px-2 py-0.5 text-[9px] uppercase tracking-wider font-extrabold bg-blue-950/45 text-blue-400 border border-blue-500/20 rounded">
                    ⭐ FAV CLUBS MATCH
                  </div>
                )}

                {/* News Image Header banner */}
                <div className="h-40 overflow-hidden relative bg-slate-950 shrink-0">
                  <img 
                    src={article.image || "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?q=80&w=800"} 
                    alt={article.title} 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover opacity-80 hover:scale-105 transition-transform duration-300" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-65" />
                  
                  {/* Category badge */}
                  <span className={`absolute bottom-3 right-3 px-2 py-0.5 text-[10px] font-bold rounded-md ${getCategoryBadgeColor(article.category)}`}>
                    {getCategoryEmojiPrefix(article.category)} {article.category.toUpperCase().replace("_", " ")}
                  </span>
                </div>

                {/* Card Content body */}
                <div className="p-5 flex flex-col justify-between flex-grow">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-white/40 font-mono tracking-widest uppercase">
                        {article.source} • {new Date(article.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      
                      {/* Priority points badge */}
                      <span className="text-[9px] bg-white/5 text-white/60 font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5 border border-white/5">
                        <Activity className="w-3 h-3 text-blue-400" /> {article.points} trending
                      </span>
                    </div>

                    <h3 className="text-sm font-bold text-white tracking-tight leading-snug line-clamp-2">
                      {article.title}
                    </h3>

                    <p className="text-xs text-white/60 line-clamp-3 font-normal leading-relaxed font-sans">
                      {article.summary}
                    </p>
                  </div>

                  {/* Actions Bar */}
                  <div className="mt-5 pt-3 border-t border-white/5 flex items-center justify-between text-xs text-white/40 shrink-0 select-none">
                    <div className="flex flex-wrap gap-1">
                      {article.clubs.map(club => (
                        <span key={club} className="text-[9px] bg-white/5 border border-white/5 px-2 py-0.5 rounded text-white/50">
                          #{club}
                        </span>
                      ))}
                    </div>

                    {userProfile && (
                      <button 
                        onClick={() => toggleSavePost(article.id)}
                        className={`p-1.5 rounded-lg border transition-all cursor-pointer flex items-center gap-1 ${
                          isBookmarked 
                            ? "border-blue-500/20 text-blue-400 bg-blue-500/5 font-semibold" 
                            : "border-white/10 text-white/60 hover:text-white hover:bg-white/5"
                        }`}
                      >
                        <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? "fill-blue-400 text-blue-400" : ""}`} />
                        <span>{isBookmarked ? "Bookmarked" : "Save"}</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
