import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { 
  Users, CreditCard, Shield, AlertTriangle, Plus, Edit2, 
  Trash2, Radio, Bell, RefreshCw, Layers, CheckCircle 
} from "lucide-react";
import { db } from "../firebase";
import { 
  collection, 
  getDocs, 
  setDoc, 
  doc, 
  deleteDoc, 
  addDoc, 
  updateDoc 
} from "firebase/firestore";
import { SubscriptionPlan, UserProfile, SubscriptionPayment } from "../types";

export const AdminHQ: React.FC = () => {
  const { userProfile } = useAuth();
  
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [payments, setPayments] = useState<SubscriptionPayment[]>([]);
  const [loading, setLoading] = useState(false);

  // Broadcaster form states
  const [broadcastTitle, setBroadcastTitle] = useState("");
  const [broadcastMessage, setBroadcastMessage] = useState("");
  const [broadcastType, setBroadcastType] = useState<"breaking" | "transfer" | "billing">("breaking");
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);

  // New/Edit plan states
  const [editingPlan, setEditingPlan] = useState<SubscriptionPlan | null>(null);
  const [isPlanModalOpen, setIsPlanModalOpen] = useState(false);
  
  // Plan form fields
  const [planId, setPlanId] = useState("");
  const [planName, setPlanName] = useState("");
  const [planPrice, setPlanPrice] = useState(1000);
  const [planDuration, setPlanDuration] = useState(14);
  const [planFeatures, setPlanFeatures] = useState("");
  const [planStatus, setPlanStatus] = useState<"active" | "inactive">("active");

  const [activeTab, setActiveTab] = useState<"plans" | "users" | "payments" | "broadcast">("plans");

  const loadAdminData = async () => {
    setLoading(true);
    try {
      // 1. Load plans from Firestore
      const plansSnap = await getDocs(collection(db, "plans"));
      const loadedPlans: SubscriptionPlan[] = [];
      plansSnap.forEach(d => {
        loadedPlans.push(d.data() as SubscriptionPlan);
      });
      setPlans(loadedPlans);

      // 2. Load users
      const usersSnap = await getDocs(collection(db, "users"));
      const loadedUsers: UserProfile[] = [];
      usersSnap.forEach(d => {
        loadedUsers.push(d.data() as UserProfile);
      });
      setUsers(loadedUsers);

      // 3. Load payments
      const paySnap = await getDocs(collection(db, "subscriptions"));
      const loadedPays: SubscriptionPayment[] = [];
      paySnap.forEach(d => {
        loadedPays.push(d.data() as SubscriptionPayment);
      });
      setPayments(loadedPays);

    } catch (err) {
      console.error("Failed to load admin data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (userProfile?.isAdmin) {
      loadAdminData();
    }
  }, [userProfile?.isAdmin]);

  const handleBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle || !broadcastMessage) return;

    try {
      // Create notification broadcast in Firestore `/notifications` collection mapping userId = "all" or specific
      const notificationId = "notif_" + Date.now();
      await setDoc(doc(db, "notifications", notificationId), {
        id: notificationId,
        userId: "all",
        title: broadcastTitle,
        message: broadcastMessage,
        type: broadcastType,
        isRead: false,
        createdAt: new Date().toISOString()
      });

      // Notify backend about the broadcast activity (triggers notifications webhook logs)
      await fetch("/api/admin/broadcast", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: broadcastTitle,
          message: broadcastMessage,
          type: broadcastType
        })
      });

      setBroadcastTitle("");
      setBroadcastMessage("");
      setBroadcastSuccess(true);
      setTimeout(() => setBroadcastSuccess(false), 3000);
      loadAdminData();
    } catch (err) {
      alert("Broadcast failed: " + (err as Error).message);
    }
  };

  const handleSavePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!planName) return;

    const id = editingPlan?.id || planId || "plan_" + Date.now();
    
    const parsedFeatures = planFeatures.split(",").map(f => f.trim()).filter(Boolean);

    const savedPlan: SubscriptionPlan = {
      id,
      name: planName,
      price: planPrice,
      durationDays: planDuration,
      features: parsedFeatures,
      status: planStatus,
      createdAt: editingPlan?.createdAt || new Date().toISOString()
    };

    try {
      await setDoc(doc(db, "plans", id), savedPlan);
      setIsPlanModalOpen(false);
      setEditingPlan(null);
      // Reset form
      setPlanId("");
      setPlanName("");
      setPlanPrice(1000);
      setPlanDuration(14);
      setPlanFeatures("");
      loadAdminData();
    } catch (err: any) {
      alert("Error saving plan: " + err.message);
    }
  };

  const handleDeletePlan = async (id: string) => {
    if (!confirm("Are you sure you want to delete this subscription plan?")) return;
    try {
      await deleteDoc(doc(db, "plans", id));
      loadAdminData();
    } catch (err: any) {
      alert("Delete failed: " + err.message);
    }
  };

  const promoteUserToPremium = async (userId: string, durationDays: number) => {
    try {
      const userRef = doc(db, "users", userId);
      const expiryDate = new Date();
      expiryDate.setDate(expiryDate.getDate() + durationDays);

      await updateDoc(userRef, {
        subscriptionId: "admin_manual",
        subscriptionStatus: "active",
        subscriptionExpiry: expiryDate.toISOString()
      });
      alert("User promoted to premium plan successfully.");
      loadAdminData();
    } catch (err: any) {
      alert("Promotion failed: " + err.message);
    }
  };

  if (!userProfile?.isAdmin) {
    return (
      <div className="p-8 text-center bg-rose-950/20 border border-rose-500/10 rounded-xl space-y-4 max-w-lg mx-auto mt-12">
        <Shield className="w-12 h-12 text-rose-400 mx-auto" />
        <h2 className="text-xl font-bold text-white font-display">Administrative Restriction</h2>
        <p className="text-slate-400 text-sm leading-relaxed">
          The Admin HQ dashboard is restricted to validated administrators. Please log in using the administrator email credentials (stevenjames2852@gmail.com) verified in our system.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6" id="admin-hq-root">
      
      {/* Admin Title & Tabs Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 bg-[#0f0f0f] border border-white/5 rounded-xl">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-white font-display flex items-center gap-2">
            <Shield className="w-5 h-5 text-blue-550" /> Admin Command Center (Verified)
          </h2>
          <p className="text-white/60 text-xs font-sans">
            Manage your subscription plans, view real-time user registrations, track ledger payments, and broadcast breaking news bulletins.
          </p>
        </div>
        <button
          onClick={loadAdminData}
          disabled={loading}
          className="text-xs bg-white/5 hover:bg-white/10 text-white font-medium px-3.5 py-1.5 border border-white/10 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} /> Refresh Hub Data
        </button>
      </div>

      {/* Tabs navigation */}
      <div className="flex border-b border-white/5">
        {[
          { key: "plans", label: "Plans Manager", icon: Layers },
          { key: "users", label: "Registered Users", icon: Users },
          { key: "payments", label: "Ledger Payments", icon: CreditCard },
          { key: "broadcast", label: "Notification Broadcaster", icon: Radio }
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as any)}
            className={`px-5 py-3 text-xs font-semibold border-b-2 flex items-center gap-2 cursor-pointer transition-colors ${
              activeTab === tab.key
                ? "border-blue-500 text-blue-400 bg-blue-500/5 font-bold"
                : "border-transparent text-white/50 hover:text-white"
            }`}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab: Plans Manager */}
      {activeTab === "plans" && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-sm font-extrabold text-white uppercase tracking-wider font-mono">
              Subscription Plans Inventory
            </h3>
            <button
              onClick={() => {
                setEditingPlan(null);
                setPlanId("");
                setPlanName("");
                setPlanPrice(1000);
                setPlanDuration(14);
                setPlanFeatures("");
                setIsPlanModalOpen(true);
              }}
              className="text-xs bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-1.5 border border-blue-500/20 rounded-lg flex items-center gap-1.5 cursor-pointer shadow-lg shadow-blue-500/10 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" /> Create New Plan
            </button>
          </div>

          <div className="overflow-x-auto bg-[#0f0f0f] border border-white/10 rounded-xl">
            <table className="w-full text-left text-xs min-w-[640px]">
              <thead className="bg-[#151515] text-white/45 uppercase tracking-wider border-b border-white/10 text-[10px] font-mono">
                <tr>
                  <th className="p-4">Plan Details</th>
                  <th className="p-4">Duration</th>
                  <th className="p-4">Cost (₦ NGN)</th>
                  <th className="p-4">Status</th>
                  <th className="p-4">Bullet Points</th>
                  <th className="p-4 text-center">Settings</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {plans.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-slate-500 italic">
                      No configurations recorded. Click &quot;Create New Plan&quot; to seed initial plans.
                    </td>
                  </tr>
                ) : (
                  plans.map(p => (
                    <tr key={p.id}>
                      <td className="p-4 font-bold text-white font-display">
                        <div>{p.name}</div>
                        <div className="text-[10px] text-slate-500 font-mono tracking-wider">{p.id}</div>
                      </td>
                      <td className="p-4 font-mono text-slate-300">{p.durationDays} Days</td>
                      <td className="p-4 font-mono font-bold text-slate-200">₦{p.price.toLocaleString()}</td>
                      <td className="p-4">
                        <span className={`px-2.5 py-0.5 rounded text-[9px] font-bold uppercase border ${
                          p.status === "active" 
                            ? "bg-blue-500/10 text-blue-400 border-blue-500/20" 
                            : "bg-white/5 text-white/40 border-white/5"
                        }`}>
                          {p.status}
                        </span>
                      </td>
                      <td className="p-4 text-slate-400 max-w-xs truncate" title={p.features.join(", ")}>
                        {p.features.join(", ")}
                      </td>
                      <td className="p-4 text-center space-x-2">
                        <button
                          onClick={() => {
                            setEditingPlan(p);
                            setPlanName(p.name);
                            setPlanPrice(p.price);
                            setPlanDuration(p.durationDays);
                            setPlanFeatures(p.features.join(", "));
                            setPlanStatus(p.status);
                            setIsPlanModalOpen(true);
                          }}
                          className="p-1.5 px-3 border border-white/10 hover:border-white/20 hover:bg-white/5 rounded-lg text-[10px] text-white/80 font-bold cursor-pointer transition-colors"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDeletePlan(p.id)}
                          className="p-1 text-rose-400 hover:text-rose-500 cursor-pointer"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Users Management Log */}
      {activeTab === "users" && (
        <div className="space-y-4">
          <h3 className="text-sm font-extrabold text-white uppercase tracking-wider font-mono">Registered Core Users</h3>

          <div className="overflow-x-auto bg-[#0f0f0f] border border-white/10 rounded-xl">
            <table className="w-full text-left text-xs min-w-[640px]">
              <thead className="bg-[#151515] text-white/45 uppercase tracking-wider border-b border-white/10 text-[10px] font-mono">
                <tr>
                  <th className="p-4">User Details</th>
                  <th className="p-4">Favorite Clubs</th>
                  <th className="p-4">Daily Uses Count</th>
                  <th className="p-4">Active Plan</th>
                  <th className="p-4">Active Expiry</th>
                  <th className="p-4 text-center">Admin Controls</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {users.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-white/40 italic">No users found in database.</td>
                  </tr>
                ) : (
                  users.map(u => {
                    const isPremium = u.subscriptionStatus === "active" && 
                                      new Date(u.subscriptionExpiry) > new Date();

                    return (
                      <tr key={u.uid}>
                        <td className="p-4">
                          <p className="font-bold text-white font-display text-sm">{u.name}</p>
                          <p className="text-white/45 text-[11px] font-mono">{u.email}</p>
                        </td>
                        <td className="p-4 text-white/60 font-sans max-w-[140px] truncate">
                          {u.favoriteClubs?.join(", ") || "-"}
                        </td>
                        <td className="p-4 font-mono text-white/60 text-center">
                          {u.dailyGenerationCount || 0} generations
                        </td>
                        <td className="p-4">
                          <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold border ${
                            isPremium 
                              ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" 
                              : "bg-[#151515] text-white/40 border-white/5"
                          }`}>
                            {isPremium ? `Premium (${u.subscriptionId})` : "Free User"}
                          </span>
                        </td>
                        <td className="p-4 font-mono text-white/50">
                          {isPremium ? new Date(u.subscriptionExpiry).toLocaleDateString() : "-"}
                        </td>
                        <td className="p-4 text-center space-x-2">
                          {!isPremium && (
                            <button
                              onClick={() => promoteUserToPremium(u.uid, 30)}
                              className="text-[10px] bg-white/5 hover:bg-white/10 border border-white/10 font-bold px-2.5 py-1.5 rounded-lg text-blue-400 cursor-pointer transition-colors"
                            >
                              🎁 Manually Gift Premium
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: payments ledger */}
      {activeTab === "payments" && (
        <div className="space-y-4">
          <h3 className="text-sm font-extrabold text-white uppercase tracking-wider font-mono">Paystack Ledgers</h3>

          <div className="overflow-x-auto bg-[#0f0f0f] border border-white/10 rounded-xl">
            <table className="w-full text-left text-xs min-w-[640px]">
              <thead className="bg-[#151515] text-white/45 uppercase tracking-wider border-b border-white/10 text-[10px] font-mono">
                <tr>
                  <th className="p-4">Billing reference</th>
                  <th className="p-4">Plan Name</th>
                  <th className="p-4">Price Paid</th>
                  <th className="p-4">Active Period</th>
                  <th className="p-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {payments.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-white/40 italic">No transactions processed yet.</td>
                  </tr>
                ) : (
                  payments.map(p => (
                    <tr key={p.id}>
                      <td className="p-4 font-mono font-bold text-white/80">{p.reference}</td>
                      <td className="p-4 font-semibold text-white/80 uppercase">{p.planId}</td>
                      <td className="p-4 font-mono text-sm text-white/85">₦{p.amount?.toLocaleString()}</td>
                      <td className="p-4 font-mono text-white/45">
                        {new Date(p.startDate).toLocaleDateString()} - {new Date(p.expiryDate).toLocaleDateString()}
                      </td>
                      <td className="p-4 text-center">
                        <span className="bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2.5 py-1 text-[9px] font-bold uppercase rounded">
                          Success
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: notification broadcaster */}
      {activeTab === "broadcast" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-5 bg-[#0f0f0f] border border-white/10 rounded-xl space-y-4">
            <h3 className="text-xs font-extrabold text-white uppercase tracking-wider flex items-center gap-1.5 font-mono">
              <Radio className="w-4 h-4 text-blue-400" /> New Broadcast Bulletin
            </h3>

            {broadcastSuccess && (
              <div className="p-3 text-xs bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-lg flex items-center gap-2">
                <CheckCircle className="w-4 h-4" /> Message broadcasted to all users successfully!
              </div>
            )}

            <form onSubmit={handleBroadcast} className="space-y-4 font-sans">
              <div>
                <label className="block text-xs font-bold text-white/45 mb-1.5 uppercase font-mono tracking-wider">Bulletin Title</label>
                <input
                  type="text"
                  placeholder="e.g. Breaking: Chelsea Complete Osimhen Transfer Deal!"
                  value={broadcastTitle}
                  onChange={(e) => setBroadcastTitle(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#151515] border border-white/5 focus:border-blue-500/55 focus:outline-none text-white rounded-lg text-xs transition-colors"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-white/45 mb-1.5 uppercase font-mono tracking-wider">Bulletin Body</label>
                <textarea
                  placeholder="Enter detailed news notification alerts context..."
                  value={broadcastMessage}
                  onChange={(e) => setBroadcastMessage(e.target.value)}
                  rows={4}
                  className="w-full px-3 py-2.5 bg-[#151515] border border-white/5 focus:border-blue-500/55 focus:outline-none text-white rounded-lg text-xs leading-relaxed transition-colors"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-white/45 mb-1.5 uppercase font-mono tracking-wider">Alert Type</label>
                <select
                  value={broadcastType}
                  onChange={(e) => setBroadcastType(e.target.value as any)}
                  className="w-full px-3 py-2.5 bg-[#151515] border border-white/5 focus:border-blue-500/55 focus:outline-none text-white rounded-lg text-xs cursor-pointer transition-colors"
                >
                  <option value="breaking">🚨 Breaking Football Alert</option>
                  <option value="transfer">🤝 Transfer Rumor Bulletin</option>
                  <option value="billing">💳 Billing / Feature Update</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow shadow-blue-500/20"
              >
                <Radio className="w-4 h-4" /> Broadcast to All Active Users
              </button>
            </form>
          </div>

          <div className="p-5 bg-white/5 border border-white/10 rounded-xl space-y-4">
            <h4 className="text-xs font-bold tracking-brand text-white/55 uppercase font-mono">Live Broadcast Example Sandbox</h4>
            <p className="text-xs text-white/45 leading-relaxed font-normal font-sans">
              Broadcasting writes a document instantly into Firestore's `/notifications` collection under `userId = "all"`. 
              All active client browsers listening dynamically receive a notification bell indicator ping immediately without reloading!
            </p>
            <div className="p-4 bg-[#0f0f0f] border border-white/5 rounded-xl space-y-1">
              <span className="bg-rose-500/10 text-rose-450 text-[9px] font-bold px-1.5 py-0.5 rounded tracking-widest uppercase font-mono">
                🚨 BREAKING
              </span>
              <h5 className="font-bold text-white text-xs mt-1.5 font-display">Simulation Notification Preview</h5>
              <p className="text-[11px] text-white/50 font-normal font-sans leading-relaxed">
                Any story broadcasted will appear inside the navigation bell menu with beautiful alert graphics instantly!
              </p>
            </div>
          </div>
          {/* Interactive Modal Plan Add/Edit creator */}
      {isPlanModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" id="plan-settings-modal">
          <div className="w-full max-w-md bg-[#0f0f0f] border border-white/10 text-white rounded-2xl shadow-2xl overflow-hidden font-sans">
            <div className="p-6 bg-gradient-to-r from-blue-700 to-blue-900 flex flex-col items-center select-none text-center">
              <Plus className="w-8 h-8 text-white mb-2" />
              <h3 className="font-extrabold text-lg text-white font-display">
                {editingPlan ? "Edit Subscription Plan" : "Create Subscription Plan"}
              </h3>
              <p className="text-xs text-white/70">Configure pricing and key feature allocations</p>
            </div>

            <form onSubmit={handleSavePlan} className="p-6 space-y-4">
              {!editingPlan && (
                <div>
                  <label className="block text-xs font-bold text-white/40 mb-1.5 uppercase font-mono tracking-wider">Plan Code (ID)</label>
                  <input
                    type="text"
                    placeholder="e.g. plan_weekly, plan_premium"
                    value={planId}
                    onChange={(e) => setPlanId(e.target.value.toLowerCase().replace(/\s+/g, "_"))}
                    className="w-full px-3 py-2 bg-[#151515] border border-white/5 focus:border-blue-500/50 text-[#e5e5e5] focus:outline-none rounded-lg text-xs font-mono"
                    required
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-white/40 mb-1.5 uppercase font-mono tracking-wider">Plan Name</label>
                <input
                  type="text"
                  placeholder="e.g. Two Week Plan"
                  value={planName}
                  onChange={(e) => setPlanName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#151515] border border-white/5 focus:border-blue-500/50 text-[#e5e5e5] focus:outline-none rounded-lg text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-white/40 mb-1.5 uppercase font-mono tracking-wider">Price (₦ NGN)</label>
                  <input
                    type="number"
                    value={planPrice}
                    onChange={(e) => setPlanPrice(parseInt(e.target.value))}
                    className="w-full px-3 py-2 bg-[#151515] border border-white/5 focus:border-blue-500/50 text-[#e5e5e5] focus:outline-none rounded-lg text-xs font-mono"
                    min={0}
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-white/40 mb-1.5 uppercase font-mono tracking-wider">Duration (Days)</label>
                  <input
                    type="number"
                    value={planDuration}
                    onChange={(e) => setPlanDuration(parseInt(e.target.value))}
                    className="w-full px-3 py-2 bg-[#151515] border border-white/5 focus:border-blue-500/50 text-[#e5e5e5] focus:outline-none rounded-lg text-xs font-mono"
                    min={1}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-white/40 mb-1.5 uppercase font-mono tracking-wider">Plan Features (Comma separated)</label>
                <textarea
                  placeholder="e.g. Unlimited content writes, Custom thread creation, Stat analysis"
                  value={planFeatures}
                  onChange={(e) => setPlanFeatures(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 bg-[#151515] border border-white/5 focus:border-blue-500/50 text-[#e5e5e5] focus:outline-none rounded-lg text-xs leading-relaxed"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-white/40 mb-1.5 uppercase font-mono tracking-wider">Active Status</label>
                <select
                  value={planStatus}
                  onChange={(e) => setPlanStatus(e.target.value as any)}
                  className="w-full px-3 py-2 bg-[#151515] border border-white/5 focus:border-blue-500/50 text-[#e5e5e5] focus:outline-none rounded-lg text-xs cursor-pointer"
                >
                  <option value="active">Active (Sellers list)</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>

              <div className="flex gap-3 pt-3 font-sans">
                <button
                  type="button"
                  onClick={() => setIsPlanModalOpen(false)}
                  className="flex-1 py-2 border border-white/10 hover:bg-white/5 text-white text-xs rounded-lg transition-colors cursor-pointer text-center font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-blue-600 hover:bg-blue-500 text-white text-xs rounded-lg transition-colors cursor-pointer text-center font-bold"
                >
                  Save Plan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}        </div>
      )}
    </div>
  );
};
