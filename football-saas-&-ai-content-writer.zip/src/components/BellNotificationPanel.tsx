import React, { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { AppNotification } from "../types";
import { db } from "../firebase";
import { collection, query, where, onSnapshot, doc, updateDoc, writeBatch } from "firebase/firestore";
import { Bell, Trash2, Check, Radio, Zap, Sparkles, CreditCard, Gift } from "lucide-react";

interface BellNotificationPanelProps {
  notifications: AppNotification[];
  unreadCount: number;
}

export const BellNotificationPanel: React.FC<BellNotificationPanelProps> = ({ notifications, unreadCount }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleMarkAsRead = async (notifId: string) => {
    try {
      const ref = doc(db, "notifications", notifId);
      await updateDoc(ref, { isRead: true });
    } catch (err) {
      console.error("Mark read failed:", err);
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      const batch = writeBatch(db);
      notifications.forEach(n => {
        if (!n.isRead) {
          const ref = doc(db, "notifications", n.id);
          batch.update(ref, { isRead: true });
        }
      });
      await batch.commit();
    } catch (err) {
      console.error("Mark all read failed:", err);
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "breaking": return <Zap className="w-4 h-4 text-rose-450 fill-rose-500/10 shrink-0 mt-0.5" />;
      case "transfer": return <Radio className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />;
      case "billing": return <CreditCard className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />;
      default: return <Sparkles className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />;
    }
  };

  return (
    <div className="relative inline-block text-left" id="notification-bell-hub">
      {/* Trigger Bell */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-lg bg-white/5 border border-white/10 text-white/70 hover:text-white transition-all hover:bg-white/10 cursor-pointer flex items-center justify-center gap-1.5"
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-rose-550 text-white font-extrabold text-[9px] w-5 h-5 flex items-center justify-center rounded-full border-2 border-[#050505] animate-bounce">
            {unreadCount}
          </span>
        )}
      </button>

      {/* Popover screen panel */}
      {isOpen && (
        <>
          {/* Overlay backdrop */}
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
          
          <div className="absolute right-0 mt-3 w-80 md:w-96 bg-[#0f0f0f] border border-white/10 text-[#e5e5e5] rounded-2xl shadow-2xl z-50 overflow-hidden transform origin-top-right transition-all">
            {/* Panel Head */}
            <div className="p-4 bg-[#151515] border-b border-white/5 flex items-center justify-between">
              <span className="text-xs font-extrabold uppercase tracking-widest text-white flex items-center gap-1.5 font-display select-none">
                <Bell className="w-4 h-4 text-blue-400" /> Alerts & Bulletins ({unreadCount})
              </span>
              {unreadCount > 0 && (
                <button
                  onClick={handleMarkAllAsRead}
                  className="text-[10px] text-blue-400 hover:text-blue-300 font-semibold cursor-pointer transition-colors"
                >
                  Mark all as read
                </button>
              )}
            </div>

            {/* List Body */}
            <div className="max-h-[320px] overflow-y-auto divide-y divide-white/5">
              {notifications.length === 0 ? (
                <div className="p-8 text-center text-slate-500 italic text-xs space-y-1">
                  <Bell className="w-6 h-6 text-slate-700 mx-auto opacity-40 mb-1" />
                  <p>Inbox is completely clean!</p>
                  <p className="text-[10px] text-slate-600">Dynamic sports alerts will appear here instantly.</p>
                </div>
              ) : (
                notifications.map(notif => (
                  <div 
                    key={notif.id} 
                    className={`p-4 flex gap-3 hover:bg-white/5 transition-colors ${
                      notif.isRead ? "opacity-65" : "bg-blue-500/5 border-l-2 border-blue-500"
                    }`}
                  >
                    {getAlertIcon(notif.type)}
                    
                    <div className="flex-grow space-y-1 my-auto">
                      <div className="flex justify-between items-start">
                        <span className="text-[10px] text-slate-500 font-mono">
                          {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        {!notif.isRead && (
                          <button
                            onClick={() => handleMarkAsRead(notif.id)}
                            className="p-0.5 rounded hover:bg-white/5 text-white/30 hover:text-blue-400 transition-colors cursor-pointer"
                            title="Mark as read"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                      <h4 className={`text-xs font-bold leading-tight ${notif.isRead ? "text-slate-350" : "text-white"}`}>
                        {notif.title}
                      </h4>
                      <p className="text-[11px] text-slate-400 font-normal leading-relaxed">
                        {notif.message}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Panel Foot */}
            <div className="p-3 bg-[#151515] border-t border-white/5 text-center text-[10px] text-white/30 font-sans">
              Broadcasting alerts dynamically to sub-recipients.
            </div>
          </div>
        </>
      )}
    </div>
  );
};
